import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { MSAdal, AuthenticationContext, AuthenticationResult } from '@ionic-native/ms-adal';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController, private msAdal: MSAdal) {

  }

  onLogin() { 
    let authContext: AuthenticationContext = this.msAdal.createAuthenticationContext('https://login.windows.net/common');
    
    authContext.acquireTokenAsync('https://graph.windows.net', 'CLIENT ID REPLACE THIS', 'http://localhost:8000', '','')
      .then((authResponse: AuthenticationResult) => {
        console.log('Token is' , authResponse.accessToken); 
        console.log('Token will expire on', authResponse.expiresOn);
        localStorage.setItem('wpIonicToken', authResponse.accessToken);
        this.navCtrl.setRoot('IntroPage');
      })
      .catch((e: any) => console.log('Authentication failed', e));
  }


}
